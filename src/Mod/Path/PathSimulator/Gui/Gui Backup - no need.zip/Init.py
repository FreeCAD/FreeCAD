# FreeCAD init script of the PathSimulator module
# (c) 2001 Juergen Riegel LGPL
