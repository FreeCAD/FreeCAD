# PathSimulator gui init module
# (c) 2001 Juergen Riegel LGPL

class PathSimulatorWorkbench ( Workbench ):
	"PathSimulator workbench object"
	MenuText = "PathSimulator"
	ToolTip = "PathSimulator workbench"
	def Initialize(self):
		# load the module
		import PathSimulatorGui
	def GetClassName(self):
		return "PathSimulatorGui::Workbench"

Gui.addWorkbench(PathSimulatorWorkbench())
